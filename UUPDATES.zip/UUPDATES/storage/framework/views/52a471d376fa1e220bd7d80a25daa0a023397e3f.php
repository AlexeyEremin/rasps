<!DOCTYPE html>
<html>
<head>
    <title>Generate PDF Laravel 8 - NiceSnippets.com</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<style type="text/css">
    h2{
        text-align: center;
        font-size:22px;
        margin-bottom:50px;
    }
    body{
        background:#f2f2f2;
    }
    .section{
        margin-top:30px;
        padding:50px;
        background:#fff;
    }
    .pdf-btn{
        margin-top:30px;
    }
</style>
<body>
<div class="container">
    <?php $__currentLoopData = $para['groups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table>
            <tr colspan="3"><?php echo e($group['name']); ?></tr>
            <?php $__currentLoopData = $group['tgts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($tgts['sub'] == 1): ?>
                    <tr>
                        <td><?php echo e($tgts['numeric']); ?></td>
                        <td><?php echo e($tgts['teacher_subject_id']); ?></td>
                        <td><?php echo e($tgts['cabinet']); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\rasp\resources\views/pdf/template_student.blade.php ENDPATH**/ ?>